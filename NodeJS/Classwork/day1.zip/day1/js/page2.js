// named function
function function1() {
  const num1 = 100
  console.log(`type of num1 = ${typeof num1}`)

  const name1 = 'steve'
  console.log(`type of name1 = ${typeof name1}`)

  const person = { name: 'person1', address: 'pune' }
  console.log(`type of person = ${typeof person}`)
}

// function1()

// arrow function / anonymous function
const function2 = () => {
  console.log(`inside function2`)
}

// function2()

// function alias
const myFunction2 = function2

myFunction2()
