// module: every js file having JS code in it

// const add = function(p1, p2) ...
function add(p1, p2) {
  console.log(`inside add = ${p1 + p2}`)
}

function subtract(p1, p2) {
  console.log(`inside subtract = ${p1 - p2}`)
}

const pi = 3.14

// export the add and subtract functions using names addFunction and subtractFunction
// so that other modules can use them
module.exports = {
  // addFunction is the name of add function which will be used by other modules
  // add is the function alias
  addFunction: add,

  // subtractFunction is name of subtract function which will be used by other modules
  // subtract is the function alias
  subtractFunction: subtract,

  pi: pi,
}

// every js file gets a new object named module added by node js
// console.log(module)
