// import the exported items from the other module
// returns the reference to the exported items from page3`
const page3 = require('./page3')

// call the function(s) from page3
page3.addFunction(10, 20)
page3.subtractFunction(20, 30)

// use the variable/constant from page3
console.log(`pi = ${page3.pi}`)
