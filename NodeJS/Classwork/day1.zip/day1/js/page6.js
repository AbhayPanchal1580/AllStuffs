const fs = require('node:fs')

function synchronousFileRead() {
  // represents sequential behavior
  // all the lines will get executed one by one

  // read the contents of myfile.txt
  console.log(`started reading the file`)

  try {
    // such functions which will block further lines are
    // called as synchronous functions or blocking functions / APIs
    // if there is any error / exception, the blocking function will throw it
    const contents = fs.readFileSync('./myfile.txt')
    console.log(`finished with reading the contents`)
    console.log(String(contents))
  } catch (ex) {
    console.log('--- exception caught')
    console.log(ex)
  }

  console.log()

  // perform math operation
  console.log('performing math operation')
  const result = 23423432234234 * 234242424224
  console.log('finished performing math operation')
  console.log(`result = ${result}`)
}

// synchronousFileRead()

function asynchronousFileRead() {
  // the lines will get executed in parallel (readFile and math operation)
  console.log(`reading file asynchronously`)

  // - readFile accepts a callback function as the last parameter
  // - starts reading the contents in a separate thread
  // - calls the callback function to pass the data and error (if any)
  // the function is known as non-blocking function / API as it is not
  // blocking the next line from its execution
  // if the asynchronous function is facing any error, instead of throwing any
  // error, it instead calls the callback function with error as the first parameter
  fs.readFile('./myfile.txt', (error, data) => {
    console.log(`finished with reading the contents`)

    // check if the error is valid
    if (error) {
      // there is an error while reading the data
      console.log(error)
    } else {
      // there is no error, we got the valid data
      console.log(String(data))
    }
  })

  // perform math operation
  console.log('performing math operation')
  const result = 23423432234234 * 234242424224
  console.log('finished performing math operation')
  console.log(`result = ${result}`)
}

// asynchronousFileRead()
