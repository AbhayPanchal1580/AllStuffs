// import http server package
const http = require('node:http')

// create the server
// accept
// request  -> input collected from client
// response -> result to be sent to the client
const server = http.createServer((request, response) => {
  console.log(`new http request received`)
  // process your request logic
  // build the response

  // return the response to the client
  response.end('<h1>this is from server....</h1>')
})

// start the server
// 0.0.0.0 => accept the network connection
// start the server on the same machine
server.listen(4000, '0.0.0.0', () => {
  console.log(`server started listening on the port4000`)
})
