const http = require('node:http')

const server = http.createServer((request, response) => {
  // process the request
  console.log(`http method: ${request.method}`)
  console.log(`http url / path: ${request.url}`)

  // send the response
  response.end('response from server')
})

server.listen(4000, '0.0.0.0', () => {
  // this function gets called only when the server started listening on port 4000 successfully
  console.log('server started on port 4000')
})
