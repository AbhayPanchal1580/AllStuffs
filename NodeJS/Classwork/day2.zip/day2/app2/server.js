// import the express js
const express = require('express')

// create an express application
const app = express()

// add the mapping for method and url
// route: mapping of method with url
app.get('/', (request, response) => {
  console.log(`received GET /`)

  // send the response
  response.send('message from server')
})

app.get('/blog', (request, response) => {
  console.log(`received GET /blog`)
  response.send('message from server')
})

app.post('/blog', (request, response) => {
  console.log('received POST /blog')
  response.send('message from server')
})

// start the express application
app.listen(3000, '0.0.0.0', () => {
  console.log(`server started on port 3000`)
})
