const express = require('express')

// array of blogs
const blogs = [
  { id: 1, title: 'blog 1', contents: 'this is my first blog' },
  { id: 2, title: 'blog 2', contents: 'this is my second blog' },
  { id: 3, title: 'blog 3', contents: 'this is my third blog' },
]

const app = express()

// middleware: function will be called everytime you send a request to the server
function log(request, response, next) {
  console.log(`inside the log function...`)
  console.log(`method = ${request.method}`)
  console.log(`url = ${request.url}`)

  // call the next function
  next()
}

// use the middleware so that the function gets called everytime
app.use(log)

// use middleware to read the contents from the request body
app.use(express.json())

app.get('/blog', (request, response) => {
  console.log(`GET /blog`)
  response.send(blogs)
})

app.post('/blog', (request, response) => {
  console.log(`POST /blog`)
  const blog = request.body
  console.log(`blog = `, blog)

  // add the new blog to the array
  blogs.push(blog)
  response.send('added a new blog')
})

app.put('/blog/:id', (request, response) => {
  console.log(request.params)

  // get the value of id from request params
  const { id } = request.params
  const updatedBlog = request.body

  // find the index of the blog having id sent by the user
  const index = blogs.findIndex((blog) => blog.id == Number(id))
  console.log(`index = ${index}`)
  if (index != -1) {
    // we found the blog with the required id
    blogs.splice(index, 1, updatedBlog)
  }
  response.send('updated the blog')
})

app.delete('/blog/:id', (request, response) => {
  // get the id of blog to be deleted
  const { id } = request.params

  // find the blog index to be delete
  const index = blogs.findIndex((blog) => blog.id == Number(id))
  if (index != -1) {
    // delete the blog from the blogs array
    blogs.splice(index, 1)
  }

  response.send('deleted the blog')
})

app.listen(3000, '0.0.0.0', () => {
  console.log(`server started on port 3000`)
})
